use [*****]


--question 1 "How many different products are offered by the store in WEEK_NO=50"
--first interpretation
select COUNT(DISTINCT T.PRODUCT_ID) AS DISTINCT_PROD_WK50
from transaction_data as T
where T.WEEK_NO=50


--question 1 "How many different products are offered by the store in WEEK_NO=50"
--second interpretation
select COUNT(DISTINCT T.PRODUCT_ID) AS DISTINCT_PROD_UNTIL_WK50
from transaction_data as T
where T.WEEK_NO<=50


--question 2 best selling product overall
--this simple query only provides the PRODUCT_ID
select T.PRODUCT_ID, SUM(T.QUANTITY) as TOTAL_SOLD
from transaction_data as T
group by T.PRODUCT_ID
order by TOTAL_SOLD DESC

--create a intermediate table to be joined with product table to get the real product description 
create table #TempTable (PRODUCT_ID int, TOTAL_SOLD bigint);

Insert into #TempTable (PRODUCT_ID, TOTAL_SOLD)
SELECT T1.*
FROM 
(
select T.PRODUCT_ID, SUM(T.QUANTITY) as TOTAL_SOLD
from transaction_data as T
group by T.PRODUCT_ID
) as T1

select *
from #TempTable as TT LEFT JOIN product as P ON TT.PRODUCT_ID=P.PRODUCT_ID
order by TOTAL_SOLD DESC

drop table #TempTable;

