use [*****]
--drop table #TempTable;


--get the number of distinct households in transaction table 
select COUNT(DISTINCT(T.household_key)) as Transaction_Number_of_HH_ID
from transaction_data as T

--get the number of distinct households in demographic table 
select COUNT(DISTINCT(D.household_key)) as Demographic_Number_of_HH_ID
from demographic as D
create table #TempTable (WK int, HH int, SALES float);


--create a new table containing the main features for random forest model

--group transactions per week and household
Insert into #TempTable (WK, HH, SALES)
SELECT T1.*
FROM 
(
select T.WEEK_NO, T.household_key, sum(T.SALES_VALUE) as SALES
from transaction_data as T
group by T.WEEK_NO, T.household_key
) as T1

--join the table above with the demographic table on household key
select TT.WK, TT.HH, D.AGE_DESC, D.INCOME_DESC, D.HOUSEHOLD_SIZE_DESC, TT.SALES
from #TempTable as TT LEFT JOIN demographic as D ON TT.HH=D.household_key
order by TT.WK ASC

--check total number of lines
select COUNT(*) AS N_LINES_TOTAL
from  #TempTable as TT LEFT JOIN demographic as D ON TT.HH=D.household_key

--check number of lines with missing values
select COUNT(*) AS N_NULL_LINES
from  #TempTable as TT LEFT JOIN demographic as D ON TT.HH=D.household_key
WHERE D.AGE_DESC is null;

--check number of complete lines 
select COUNT(*) AS N_NOT_NULL_LINES
from  #TempTable as TT LEFT JOIN demographic as D ON TT.HH=D.household_key
WHERE D.AGE_DESC is not null;

drop table #TempTable;

