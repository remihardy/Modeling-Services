library(tseries)
library(forecast)


#---------------------------------
#Load dataset
#---------------------------------

week_serie = read.csv('D:\\*****\\week_serie.csv', header=FALSE, stringsAsFactors = FALSE)
names(week_serie)=c('Week','Sales')
options(scipen=10)
plot(week_serie$Sales, xlab='Weeks', ylab='Sales', type='l', col='blue', main='SALES PER WEEK')

#---------------------------------
#Preprocessing
#---------------------------------

#remove the 14 first point as they represent the sales ramping of the retail obviously
WS=week_serie[-(1:14),]
plot(WS$Sales, x=WS$Week, xlab='Weeks', ylab='Sales', type='l', col='blue', main='SALES PER WEEK')


#---------------------------------
#check stationarity 
#---------------------------------
#The null hypothesis 
#H0: the time series is non stationary
#H1: the time series is stationary
adf.test(WS$Sales)
#the p-value is >0.05 significant level 
#therefore we CANNOT reject the null hypothesis that the serie non stationary 

#Dickey-Fuller = -2.8374, Lag order = 4, p-value = 0.2326
#alternative hypothesis: stationary

#---------------------------------
#ARIMA model
#stationary with lag=1 differenciation
#---------------------------------

#check auto arima proposal
#(3,1,1)
#AIC=1641 ; BIC=1658
auto.arima(WS$Sales, trace=TRUE)
auto_fit <- arima(WS$Sales, c(3, 1, 3))
auto_pred <- predict(auto_fit, n.ahead = 10)

#custom check
#analyze the ACF and PACF schemes with differentiation (default lag=1) to identify the model
acf(diff(WS$Sales))        
pacf(diff(WS$Sales))

#ARIMA (5.1.0) as (p d q) according to ACF and PACF analysis
#provides AIC and BIC slightly lower values (thus better) than the auto arima
my_fit <- arima(WS$Sales, c(5, 1, 0))
my_pred <- predict(my_fit, n.ahead = 10)

#check goodness of fit criterions for "my_fit"
print(AIC(my_fit))
print(BIC(my_fit))


#---------------------------------
#ARIMA model
#check residuals
#---------------------------------

#check residuals normality
qqnorm(my_fit$residuals)
qqline(my_fit$residuals, col='red')

#KS test: in this case, we test the sample distribution against a normal distribution 
ks.test(unique(my_fit$residuals),'pnorm',mean(unique(my_fit$residuals)),sd(unique(my_fit$residuals)))
#H0 the 2 distribution are identical 
#Ha the 2 distributions are NOT identical
#One-sample Kolmogorov-Smirnov test
#data:  unique(my_fit$residuals)
#D = 0.1008, p-value = 0.3446
#we cannot reject the NULL hypothesis, 
#thus we can accept the assumption that the distribution is identical to a normal distribution

#plotting the normal distribution over the residuals
xmin=min(my_fit$residuals)
xmax=max(my_fit$residuals)
A=hist(my_fit$residuals)
A=hist(my_fit$residuals,freq=FALSE, xlim=c(xmin,xmax),ylim=c(0,1.1*max(A$density)), xlab='',ylab='',main='Residuals Distribution vs Normal')
mu=mean(unique(my_fit$residuals))
sd=sd(unique(my_fit$residuals))
x=seq(xmin,xmax,1000)
y=dnorm(x,mu,sd)
par(new=TRUE)
plot(x, y, type="l", col='red', lwd=1, xlim=c(xmin,xmax),ylim=c(0,1.1*max(A$density)), xlab='',ylab='',main='Residuals Distribution vs Normal')

#---------------------------------
#Build the matrix to plot the different timeseries
#---------------------------------

#number of points to be predicted
ahead=10

#initial lenght of week serie
initial_length=dim(WS)[1]

#add empty columns for Auto Pred and My Pred into the dataframe 
tmp_vec1=rep(NA,initial_length)
WS=as.data.frame(cbind(WS,tmp_vec1,tmp_vec1))
names(WS)=c('Week','Sales','AutoPred', 'MyPred')

#build new rows (tmp_df) containing the predictions
start=as.integer(WS$Week[initial_length])+1
end=as.integer(WS$Week[initial_length])+ahead
w=seq(start,end,1)

empty_vec=rep(NA,end-start+1)
auto_pred_vec=floor(auto_pred$pred)
my_pred_vec=floor(my_pred$pred)
tmp_df=data.frame(w,empty_vec,auto_pred_vec,my_pred_vec)
rownames(tmp_df) = start:end
names(tmp_df)=c('Week','Sales','AutoPred', 'MyPred')

#build new table with Sales and Predictions
new_WS=rbind(WS,tmp_df)

#---------------------------------
#Plot the 10 points ahead for the 2 models (3,1,3) and (5,1,0)
#---------------------------------
ymin=min(WS$Sales)
ymax=max(WS$Sales)
plot(new_WS$Sales, x=new_WS$Week, col='blue', type='l', ylim=c(ymin,ymax), xlab='Weeks',ylab='Sales', main='Future Sales Estimation')
par(new=TRUE)
plot(new_WS$AutoPred, x=new_WS$Week, col='red', type='l',ylim=c(ymin,ymax), xlab='Weeks', ylab='Sales', main='Future Sales Estimation')
par(new = TRUE)
plot(new_WS$MyPred, x=new_WS$Week, col='green', type='l',ylim=c(ymin,ymax), xlab='Weeks', ylab='Sales', main='Future Sales Estimation')
legend("topleft", legend=c("Current Sales","Future Sales Auto-Arima model (3,1,3)", "Future Sales, Custom model (5,1,0)"), col=c("blue","red", "green"), lty=1, cex=0.8)


#---------------------------------
#Training / Test to compare with Random Forest
#---------------------------------

#split train and test roughly 70/30
train=WS$Sales[1:60]
test=WS$Sales[61:83]

#fit train with (5,1,0) and compute MAPE
#MAPE is slighly higher with auto arima
my_fit <- arima(train, c(5, 1, 0), method='ML')
pred <- predict(my_fit, n.ahead = 23)
mape=mean(abs((test - pred$pred) / test)) 
print(mape) #4.5%
#compute a few statistics from the error vector
mape_vec=abs((test - pred$pred) / test)
max(mape_vec)
sd(mape_vec)



#fit train with (3,1,3) and compute MAPE
my_fit <- arima(train, c(3, 1, 3), method='ML')
pred <- predict(my_fit, n.ahead = 23)
mape=mean(abs((test - pred$pred) / test)) 
print(mape) #4.9%


#plot Y and Yhat based on (5,1,0) on the test sample
w=seq(61,83,1)
comp=data.frame(cbind(w,test,pred$pred))
names(comp)=c('Week','Y','Yhat')

ymin=min(comp$Y,comp$Yhat)
ymax=max(comp$Y,comp$Yhat)
plot(comp$Y, x=comp$Week, col='blue', type='b', ylim=c(ymin,ymax), ylab='Sales',xlab='Weeks', main='Sales Estimation on Test Sample')
par(new=TRUE)
plot(comp$Yhat, x=comp$Week, col='red', type='b', ylim=c(ymin,ymax), ylab='Sales',xlab='Weeks', main='Sales Estimation on Test Sample')
legend("topleft", legend=c("Actual Sales", "Estimated Sales"), col=c("blue", "red"), lty=1, cex=0.8)

