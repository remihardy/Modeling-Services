use [*****]


--number of transactions where quantity = 0
select * 
from transaction_data as T
where T.QUANTITY=0 AND T.SALES_VALUE!=0


--number of transactions where sales_value = 0
select COUNT(*)
from transaction_data as T
where T.SALES_VALUE=0 AND T.QUANTITY=0

select *
from transaction_data as T
where T.SALES_VALUE=0 AND T.QUANTITY=0 AND COUPON_DISC=0 AND COUPON_MATCH_DISC=0 AND RETAIL_DISC=0