use [*****]


---raw DAY serie
select T.DAY, FLOOR(SUM(T.SALES_VALUE)) AS SALES
from transaction_data as T
group by T.DAY
order by T.DAY ASC

--raw WEEK serie
select T.WEEK_NO, FLOOR(SUM(T.SALES_VALUE)) AS SALES
from transaction_data as T
group by T.WEEK_NO





