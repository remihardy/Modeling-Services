# -*- coding: utf-8 -*-
"""
Created on Wed Jul 24 19:01:31 2019

@author: HARDY
"""

# Using Recurrent Neural Network (LSTM)

from numpy.random import seed
seed(1234)

#-------------------------------------
#PARAMETERS
#-------------------------------------

FILE_PATH='week_serie.csv'
LAG=20
N_EPOCH=100
BATCH_SIZE=2 # 2 samples per gradient update => 20 updates per epoch


#-------------------------------------
#LIBS
#-------------------------------------
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

#-------------------------------------
#Data Preprocessing
#-------------------------------------

# Importing the training set
data = pd.read_csv(FILE_PATH, sep=',', header=None, names={'Week','Sales'})
#train is size 60; test is size 23 after cutting off the 14 first values
train = data.iloc[14:74, 1:2].values
test = data.iloc[74:len(data), 1:2].values

# Feature Scaling, Normalization is recommended for RNN
from sklearn.preprocessing import MinMaxScaler
sc = MinMaxScaler(feature_range = (0, 1))
training_set_scaled = sc.fit_transform(train)

# Creating the data structure
X_train = []
y_train = []

#with LAG=20
#we get x_train 60-20=40 vectors from 0:19 to 40:59 size t=20
for i in range(LAG, 60):
    X_train.append(training_set_scaled[i-LAG:i, 0])
    y_train.append(training_set_scaled[i, 0])
X_train, y_train = np.array(X_train), np.array(y_train)

X_train = np.reshape(X_train, (X_train.shape[0], X_train.shape[1], 1))


#-------------------------------------
#KERAS RNN
#-------------------------------------

# Importing the Keras libraries and packages
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import LSTM
from keras.layers import Dropout

# Initialising the RNN
regressor = Sequential()

# Adding the first LSTM layer 
regressor.add(LSTM(units = 50, input_shape = (X_train.shape[1], 1)))

# Adding the output layer
regressor.add(Dense(units = 1))

# Compiling the RNN
# optimizer RMSprop is recommended for RNN in principle, but Adam gives better result so far
regressor.compile(optimizer = 'adam', loss = 'mean_squared_error')

# Fitting the RNN to the Training set
regressor.fit(X_train, y_train, epochs = N_EPOCH, batch_size = BATCH_SIZE)



#-------------------------------------
#Apply test data
#-------------------------------------

dataset_total = data.iloc[14:len(data),1].values
#inputs is size 43 (=23 + 20)
inputs = dataset_total[len(dataset_total) - len(test) - LAG:]
inputs = inputs.reshape(-1,1) #row unknow, col 1
inputs = sc.transform(inputs)
X_test = []
#we get x_test 43-20=23 vectors of size t=20
for i in range(LAG, len(inputs)):
    X_test.append(inputs[i-LAG:i, 0])
X_test = np.array(X_test)
X_test = np.reshape(X_test, (X_test.shape[0], X_test.shape[1], 1))
predicted_sales = regressor.predict(X_test)
predicted_sales = sc.inverse_transform(predicted_sales)


#--------------------------
#METRICS
#-------------------------

#absolute percent error (vector)
aperr= np.abs(test[:,0] - predicted_sales[:,0]) / test[:,0]
mape=np.mean(aperr)
print('MAPE = ' + str(mape))


#--------------------------
#PLOT
#-------------------------

test=test.reshape(23)
predicted_sales=predicted_sales.reshape(23)
plt.plot(test, 'bo-', label = 'Actual Sales')
plt.plot(predicted_sales, 'ro-', label = 'Predicted Sales')
plt.title('Sales Prediction')
plt.xlabel('Week')
plt.ylabel('Sales')
plt.legend()
plt.show()
