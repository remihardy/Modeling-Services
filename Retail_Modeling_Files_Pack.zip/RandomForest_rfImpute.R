library(randomForest)
set.seed(1234)

#---------------------------------
#Load dataset and Plot Serie
#---------------------------------

data = read.csv('D:\\******\\RandomForest_features.csv', header=FALSE, stringsAsFactors = FALSE)
names(data)=c('WK','HH','AGE','INCOME','HH_SIZE','SALES')
data$WK[1]=1

#---------------------------------
#RE BUILD the features PER WEEK
#IMPUTATION using RFIMPUTE
#---------------------------------

#check factors
str(data)
#replace NULL by NA
is.na(data) <- data == "NULL"

#change data types and convert to factors
data$WK=as.numeric(data$WK)
data$AGE=as.factor(data$AGE)
data$INCOME=as.factor(data$INCOME)
data$HH_SIZE=as.factor(data$HH_SIZE)

#week number
week=seq(1,97,1)

#household number
n_hh=sort(as.matrix(table(data$WK)))

#age/imcome/hh_size class frequency
age=vector()
income=vector()
hh_size=vector()
for (i in week) {
  data_imputed <- rfImpute(SALES ~ ., data[data$WK==i,])
  age=rbind(age,as.vector(table(data_imputed$AGE)))
  income=rbind(income,as.vector(table(data_imputed$INCOME)))
  hh_size=rbind(hh_size,as.vector(table(data_imputed$HH_SIZE)))
}

age=as.data.frame(age)
#names(age)=c('19-24','25-34','35-44','45-54','55-64','65+')
names(age)=c('A1','A2','A3','A4','A5','A6')

income=as.data.frame(income)
#names(income)=c('100-124k','125-149k','15-24k','150-174k','175-199k','200-249k','25-34k','250k+','35-49k','50-74k','75-99k','under 15k')
names(income)=c('I1','I2','I3','I4','I5','I6','I7','I8','I9','I10','I11','I12')

hh_size=as.data.frame(hh_size)
names(hh_size)=c('P1','P2','P3','P4','P5')

#sum of sales
sales=vector()
for (i in week) {
  sales=rbind(sales,sum(data[data[,1]==i,6]))
}
sales=data.frame(sales)
names(sales)=c('Sales')

#aggregate the new data frame
all_features=cbind(week,n_hh,age,income,hh_size,sales)

#remove the 14 first point as they represent the sales ramping of the retail obviously
data_rf=all_features[-(1:14),]
plot(data_rf$Sales, x=data_rf$week, xlab='Weeks', ylab='Sales', type='l', col='blue', main='SALES PER WEEK')


#---------------------------------
#predict week98
#---------------------------------

#build the features for week 98 using the mean of the past weeks
test_vec=data.frame(colMeans(data_rf))
test_vec[1,1]=98
test_vec=t(test_vec)
row.names(test_vec)="98"
data_rf=rbind(data_rf, test_vec)

train=data_rf[1:83,]
test=data_rf[84,]

modrf <- randomForest(Sales ~ ., data=train, importance=TRUE)
pred <- predict(modrf, newdata=test)


#---------------------------------
#Training / Test to compare with ARIMA
#---------------------------------

#split train and test roughly 70/30
train=data_rf[1:60,]
test=data_rf[61:83,]

modrf <- randomForest(Sales ~ ., data=train, importance=TRUE)
pred <- predict(modrf, newdata=test)

#compute the MAPE and a few statistics for comparison
mape=mean(abs((test$Sales - pred) / test$Sales)) 
print(mape)
mape_vec=abs((test$Sales - pred) / test$Sales)
max(mape_vec)
sd(mape_vec)

#plot Y and Yhat on the test sample
w=seq(61,83,1)
comp=data.frame(cbind(w,test$Sales,pred))
names(comp)=c('Week','Y','Yhat')

ymin=min(comp$Y,comp$Yhat)
ymax=max(comp$Y,comp$Yhat)
plot(comp$Y, x=comp$Week, col='blue', type='b', ylim=c(ymin,ymax), ylab='Sales',xlab='Weeks', main='Sales Estimation on Test Sample')
par(new=TRUE)
plot(comp$Yhat, x=comp$Week, col='red', type='b', ylim=c(ymin,ymax), ylab='Sales',xlab='Weeks', main='Sales Estimation on Test Sample')
legend("topleft", legend=c("Actual Sales", "Estimated Sales"), col=c("blue", "red"), lty=1, cex=0.8)


