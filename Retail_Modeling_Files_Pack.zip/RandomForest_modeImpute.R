library(randomForest)
set.seed(1234)

#---------------------------------
#Load dataset and Plot Serie
#---------------------------------

data = read.csv('D:\\******\\RandomForest_features.csv', header=FALSE, stringsAsFactors = TRUE)
names(data)=c('WK','HH','AGE','INCOME','HH_SIZE','SALES')
data$WK[1]=1

#---------------------------------
#RE BUILD the features PER WEEK
#IMPUTATION using (overall) MODE (notice : not the weekly MODE)
#---------------------------------

#week number
week=seq(1,97,1)

#household number
n_hh=sort(as.matrix(table(data$WK)))
n_hh=n_hh[2:98]

#age class frequency
table(data$AGE)
age=vector()
for (i in week) {
  age=rbind(age,as.vector(table(data[data[,1]==i,3])))
}
age[,4]=age[,4]+age[,7]
age=data.frame(age[,-7])
#names(age)=c('19-24','25-34','35-44','45-54','55-64','65+')
names(age)=c('A1','A2','A3','A4','A5','A6')

#income class frequency
table(data$INCOME)
income=vector()
for (i in week) {
  income=rbind(income,as.vector(table(data[data[,1]==i,4])))
}
income[,10]=income[,10]+income[,12]
income=data.frame(income[,-12])
#names(income)=c('100-124k','125-149k','15-24k','150-174k','175-199k','200-249k','25-34k','250k+','35-49k','50-74k','75-99k','under 15k')
names(income)=c('I1','I2','I3','I4','I5','I6','I7','I8','I9','I10','I11','I12')


#household size class frequency
table(data$HH_SIZE)
hh_size=vector()
for (i in week) {
  hh_size=rbind(hh_size,as.vector(table(data[data[,1]==i,5])))
}
hh_size[,2]=hh_size[,2]+hh_size[,6]
hh_size=data.frame(hh_size[,-6])
names(hh_size)=c('P1','P2','P3','P4','P5')

#sum of sales
sales=vector()
for (i in week) {
  sales=rbind(sales,sum(data[data[,1]==i,6]))
}
sales=data.frame(sales)
names(sales)=c('Sales')

#aggregate the new data frame
all_features=cbind(week,n_hh,age,income,hh_size,sales)

#remove the 14 first point as they represent the sales ramping of the retail obviously
data_rf=all_features[-(1:14),]
plot(data_rf$Sales, x=data_rf$week, xlab='Weeks', ylab='Sales', type='l', col='blue', main='SALES PER WEEK')


#---------------------------------
#predict week98
#---------------------------------

#build the features for week 98 using the mean of the past weeks
test_vec=data.frame(colMeans(data_rf))
test_vec[1,1]=98
test_vec=t(test_vec)
row.names(test_vec)="98"
data_rf=rbind(data_rf, test_vec)

train=data_rf[1:83,]
test=data_rf[84,]

modrf <- randomForest(Sales ~ ., data=train, importance=TRUE)
pred <- predict(modrf, newdata=test)


#---------------------------------
#Training / Test to compare with ARIMA
#---------------------------------

#split train and test roughly 70/30
train=data_rf[1:60,]
test=data_rf[61:83,]

modrf <- randomForest(Sales ~ ., data=train, importance=TRUE)
pred <- predict(modrf, newdata=test)

#compute the MAPE and a few statistics for comparison
mape=mean(abs((test$Sales - pred) / test$Sales)) 
print(mape)
mape_vec=abs((test$Sales - pred) / test$Sales)
max(mape_vec)
sd(mape_vec)

#plot Y and Yhat on the test sample
w=seq(61,83,1)
comp=data.frame(cbind(w,test$Sales,pred))
names(comp)=c('Week','Y','Yhat')

ymin=min(comp$Y,comp$Yhat)
ymax=max(comp$Y,comp$Yhat)
plot(comp$Y, x=comp$Week, col='blue', type='b', ylim=c(ymin,ymax), ylab='Sales',xlab='Weeks', main='Sales Estimation on Test Sample')
par(new=TRUE)
plot(comp$Yhat, x=comp$Week, col='red', type='b', ylim=c(ymin,ymax), ylab='Sales',xlab='Weeks', main='Sales Estimation on Test Sample')
legend("topleft", legend=c("Actual Sales", "Estimated Sales"), col=c("blue", "red"), lty=1, cex=0.8)



