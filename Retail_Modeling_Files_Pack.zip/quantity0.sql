use [*****]

--number of transactions where quantity = 0
select COUNT(*) as QTY0
from transaction_data as T
where T.QUANTITY=0

--number of transactions where sales_value = 0
select COUNT(*) as QTY0_SALES0
from transaction_data as T
where T.SALES_VALUE=0 AND T.QUANTITY=0

--number of transactions where sales is different from 0 but quantity = 0 
select *
from transaction_data as T
where T.SALES_VALUE!=0 AND T.QUANTITY=0
