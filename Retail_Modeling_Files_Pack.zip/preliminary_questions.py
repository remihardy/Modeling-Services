# -*- coding: utf-8 -*-
"""
Created on Thu Jun 20 22:25:01 2019

@author: HARDY
"""

#-------------------------------------
#PARAMETERS
#-------------------------------------

FILE_PATH='****'

#-------------------------------------
#LIBS
#-------------------------------------
import numpy as np
import pandas as pd


#-------------------------------------
#load main data set
#-------------------------------------

df = pd.read_csv(FILE_PATH,sep=',')


#-------------------------------------
#Preliminary questions
#-------------------------------------


#question 1 "How many different products are offered by the store in WEEK_NO=50"

#extract week 50 ONLY
wk50=df.loc[df['WEEK_NO'] == 50]
wk50=wk50.reset_index()
#init dictionary
prod_dict={}
#parse wk50 subset
for line in range(len(wk50)):
    product_id=wk50.loc[line, 'PRODUCT_ID'] 
    quantity=wk50.loc[line, 'QUANTITY'] 
    #build the dictionary with distinct product_id as key
    #value is not important
    if product_id not in prod_dict:
        prod_dict[product_id]=1
print('Number of distinct products from the store in week 50 = ', str(len(prod_dict)))



#question 2 "best selling product overall"

#we use the complete dataset aka df
#init dictionary
prod_dict={}
#parse the complete dataset
for line in range(len(df)):
    product_id=df.loc[line, 'PRODUCT_ID'] 
    quantity=df.loc[line, 'QUANTITY']
    #build the dictionary with distinct product_id as key
    #value is the cumulative quantity of product_id sold
    if product_id not in prod_dict:
        prod_dict[product_id]=quantity 
    else:
        prod_dict[product_id]+=quantity

best_selling_id=max(prod_dict, key=prod_dict.get)
best_selling_qty=prod_dict[best_selling_id]
print('best selling product_id=', best_selling_id, 'with quantity sold=',str(best_selling_qty))


